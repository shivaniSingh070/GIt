<?php
/**
 * @author : AA
 * @template-Version : Magento 2.3.1
 * @description : Register the Extension
 * @date : 19.06.2019
 * @Trello: https://trello.com/c/7yfEDXmg
 */

\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'Pixelmechanics_ExportOrder',
    __DIR__
);

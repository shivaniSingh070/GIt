<?php 
/*
 * Created a extension for Customer Attribute
 * Updated by AA 07.11.2019
 * Trello: https://trello.com/c/ytbOL9Aw/291-prio-1-new-customer-numbers#comment-5dc2cba65c2afc39cd6708a2
*/
?>
<?php
\Magento\Framework\Component\ComponentRegistrar::register(
	\Magento\Framework\Component\ComponentRegistrar::MODULE,
	'Pixelmechanics_CustomerAttribute',
	__DIR__
);


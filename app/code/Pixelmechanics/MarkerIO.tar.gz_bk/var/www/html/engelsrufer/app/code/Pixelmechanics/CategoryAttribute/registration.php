<?php 
/*
 * Created a extension for category Attribute
 * Register extension
 * Updated by AA 21.05.2019
 * Trello: https://trello.com/c/iD9HOWhj/
*/
?>
<?php
\Magento\Framework\Component\ComponentRegistrar::register(
	\Magento\Framework\Component\ComponentRegistrar::MODULE,
	'Pixelmechanics_CategoryAttribute',
	__DIR__
);


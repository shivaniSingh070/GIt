<?php 
/*
 * @author NA by 29.07.19
 * Add the Bread Crumb on the Product Page.
 * Trello: https://trello.com/c/XeGnBIAN/94-021-mobile-menue-mobile-anpassung-mobiles-men%C3%BC	
*/
?>
<?php
\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'Pixelmechanics_User',
    __DIR__
);

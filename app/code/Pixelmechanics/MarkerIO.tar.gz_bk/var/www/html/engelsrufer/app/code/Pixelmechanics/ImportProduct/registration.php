<?php

/**
 * @author : AA
 * @template-Version : Magento 2.3.1
 * @description : Register the extension
 * @date : 5.08.2019
 * @Trello: https://trello.com/c/pk8egBYL
 */

\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'Pixelmechanics_ImportProduct',
    __DIR__
);

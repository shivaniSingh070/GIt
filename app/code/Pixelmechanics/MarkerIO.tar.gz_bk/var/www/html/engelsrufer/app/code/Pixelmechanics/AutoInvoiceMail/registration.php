<?php
/**
 * @author : AA
 * @template-Version : Magento 2.3.1
 * @description : Register the Extension "Pixelmechanics_AutoInvoiceMail"
 * @date : 19.11.2019
 * @Trello: https://trello.com/c/dEw7KpFf/28-rechnungsdruck-senden-der-rechnungen#comment-5dd3d76bd22de67129b59560
 */

\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'Pixelmechanics_AutoInvoiceMail',
    __DIR__
);

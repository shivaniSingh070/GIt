<?php
/*
* @author : AA
* @Date :   02.07.2019
* @Description : Override the current model to get html data of terms and conditions.
*/

namespace Pixelmechanics\Agreements\Rewrite\Magento\CheckoutAgreements\Model;

use Magento\Checkout\Model\ConfigProviderInterface;
use Magento\Framework\App\ObjectManager;
use Magento\Store\Model\ScopeInterface;
use Magento\CheckoutAgreements\Model\Api\SearchCriteria\ActiveStoreAgreementsFilter;

class AgreementsConfigProvider extends \Magento\CheckoutAgreements\Model\AgreementsConfigProvider
{


	/**
	 * @var \Magento\Framework\App\Config\ScopeConfigInterface
	 */
	protected $scopeConfiguration;

	/**
	 * @var \Magento\CheckoutAgreements\Api\CheckoutAgreementsRepositoryInterface
	 */
	protected $checkoutAgreementsRepository;

	/**
	 * @var \Magento\Framework\Escaper
	 */
	protected $escaper;

	/**
	 * @var \Magento\CheckoutAgreements\Api\CheckoutAgreementsListInterface
	 */
	private $checkoutAgreementsList;

	/**
	 * @var ActiveStoreAgreementsFilter
	 */
	private $activeStoreAgreementsFilter;
        
        /**
         * @var \Magento\Cms\Model\Template\FilterProvider
        */
         protected $_filterProvider;

	/**
	 * @param \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfiguration
	 * @param \Magento\CheckoutAgreements\Api\CheckoutAgreementsRepositoryInterface $checkoutAgreementsRepository
	 * @param \Magento\Framework\Escaper $escaper
	 * @param \Magento\CheckoutAgreements\Api\CheckoutAgreementsListInterface|null $checkoutAgreementsList
	 * @param ActiveStoreAgreementsFilter|null $activeStoreAgreementsFilter
	 * @codeCoverageIgnore
	 */
	public function __construct(
	    \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfiguration,
            \Magento\Cms\Model\Template\FilterProvider $filterProvider,
	    \Magento\CheckoutAgreements\Api\CheckoutAgreementsRepositoryInterface $checkoutAgreementsRepository,
	    \Magento\Framework\Escaper $escaper,
	    \Magento\CheckoutAgreements\Api\CheckoutAgreementsListInterface $checkoutAgreementsList = null,
	    ActiveStoreAgreementsFilter $activeStoreAgreementsFilter = null
	) {
	    $this->scopeConfiguration = $scopeConfiguration;
            $this->_filterProvider =$filterProvider;
	    $this->checkoutAgreementsRepository = $checkoutAgreementsRepository;
	    $this->escaper = $escaper;
	    $this->checkoutAgreementsList = $checkoutAgreementsList ?: ObjectManager::getInstance()->get(
	        \Magento\CheckoutAgreements\Api\CheckoutAgreementsListInterface::class
	    );
	    $this->activeStoreAgreementsFilter = $activeStoreAgreementsFilter ?: ObjectManager::getInstance()->get(
	        ActiveStoreAgreementsFilter::class
	    );
	}

	/**
     * @inheritdoc
     */
    public function getConfig()
    {
        $agreements = [];
        $agreements['checkoutAgreements'] = $this->getAgreementsConfig();

        return $agreements;
    }

	protected function getAgreementsConfig()
    {
        $agreementConfiguration = [];
        $isAgreementsEnabled = 1;

        $agreementsList = $this->checkoutAgreementsList->getList(
            $this->activeStoreAgreementsFilter->buildSearchCriteria()
        );
        $agreementConfiguration['isEnabled'] = (bool)($isAgreementsEnabled && count($agreementsList) > 0);

        foreach ($agreementsList as $agreement) {
        /* Removed  escapeHtml from checkboxText and added filterprovide to resolve store url issue */
            $textValue = $this->_filterProvider->getPageFilter()->filter($agreement->getCheckboxText() );
            $agreementConfiguration['agreements'][] = [
                'content' => $agreement->getIsHtml()
                    ? $agreement->getContent()
                    : nl2br($this->escaper->escapeHtml($agreement->getContent())),
                'checkboxText' => $textValue,
                'mode' => $agreement->getMode(),
                'agreementId' => $agreement->getAgreementId()
            ];
        }

        return $agreementConfiguration;
    }

}

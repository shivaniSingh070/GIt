define([
    'jquery',
    'mage/utils/wrapper'
], function ($, wrapper) {
    'use strict';

    return function (targetModule) {
        var updatePrice = targetModule.prototype._UpdatePrice;
        //get value of attributes according to simple product selected and updated HTML, updated by AA on 22.08.2019
        targetModule.prototype.configurableSku = $('div.product-desc .sku-value').html();
        targetModule.prototype.configurableDescription = $('div.product-desc-value').html();
        targetModule.prototype.configurablebulletpoint1 = $('li.bullet-point1').html();
        targetModule.prototype.configurablebulletpoint2 = $('li.bullet-point2').html();
        targetModule.prototype.configurablebulletpoint3 = $('li.bullet-point3').html();
        targetModule.prototype.configurablebulletpoint4 = $('li.bullet-point4').html();
        targetModule.prototype.configurablebulletpoint5 = $('li.bullet-point5').html();
        targetModule.prototype.configurableproductType = $('.producttype-value').html();
        targetModule.prototype.configurablestoneType = $('.stonetype-value').html();

        targetModule.prototype.configurablefunktion = $('.function-value').html();
        targetModule.prototype.configurabledurchmesser_hoehe = $('.durchmesser_hoehe-value').html();
        targetModule.prototype.configurablethickness = $('.thickness-value').html();
        targetModule.prototype.configurableverschlusstypen = $('.verschlusstypen-value').html();
        targetModule.prototype.configurablelange_cm = $('.lange_cm-value').html();

        targetModule.prototype.configurablematerialLegierung = $('.materialLegierung-value').html();
        targetModule.prototype.configurablegoldlegierung = $('.goldlegierung-value').html();
        targetModule.prototype.configurablesize = $('.size-value').html();
        targetModule.prototype.configurablecolor = $('.color-value').html();
        targetModule.prototype.configurablequalityDetailsLabel = $('.qualityDetailsLabel').html();
        targetModule.prototype.configurablequalityDetails = $('.qualityDetails').html();
        targetModule.prototype.configurableKlangfarbeLabel = $('.klangfarbeLabel').html();
        targetModule.prototype.configurableKlangfarbe = $('.klangfarbe').html();
        targetModule.prototype.configurableverpackungLabel = $('.verpackungLabel').html();
        targetModule.prototype.configurableverpackung = $('.verpackung').html();
        targetModule.prototype.configurableengelsruferKonzeptLabel = $('.engelsruferKonzeptLabel').html();
        targetModule.prototype.configurableengelsruferKonzeptValue = $('.engelsruferKonzeptValue').html();
        targetModule.prototype.configurableverpackungImage = $('.verpackungImg img').attr('src');
        targetModule.prototype.configurableengelsruferKonzeptImage = $('.engelsruferKonzeptImage img').attr('src');
        var updatePriceWrapper = wrapper.wrap(updatePrice, function (original) {
            var allSelected = true;
            for (var i = 0; i < this.options.jsonConfig.attributes.length; i++) {
                if (!$('div.product-info-main .product-options-wrapper .swatch-attribute.' + this.options.jsonConfig.attributes[i].code).attr('option-selected')) {
                    allSelected = false;
                }
            }
            var simpleSku = this.configurableSku;
            if (allSelected) {
                var products = this._CalcProducts();
                simpleSku = this.options.jsonConfig.skus[products.slice().shift()];
            }
            var simpleDescription = this.configurableDescription;
            if (allSelected) {
                var products = this._CalcProducts();
                simpleDescription = this.options.jsonConfig.details[products.slice().shift()];
            }
            var simplebulletPoint1 = this.configurablebulletpoint1;
            if (allSelected) {
                var products = this._CalcProducts();
                simplebulletPoint1 = this.options.jsonConfig.bulletPoint1[products.slice().shift()];
            }
            var simplebulletPoint2 = this.configurablebulletpoint2;
            if (allSelected) {
                var products = this._CalcProducts();
                simplebulletPoint2 = this.options.jsonConfig.bulletPoint2[products.slice().shift()];
            }
            var simplebulletPoint3 = this.configurablebulletpoint3;
            if (allSelected) {
                var products = this._CalcProducts();
                simplebulletPoint3 = this.options.jsonConfig.bulletPoint3[products.slice().shift()];
            }
            var simplebulletPoint4 = this.configurablebulletpoint4;
            if (allSelected) {
                var products = this._CalcProducts();
                simplebulletPoint4 = this.options.jsonConfig.bulletPoint4[products.slice().shift()];
            }
            var simplebulletPoint5 = this.configurablebulletpoint5;
            if (allSelected) {
                var products = this._CalcProducts();
                simplebulletPoint5 = this.options.jsonConfig.bulletPoint5[products.slice().shift()];
            }
            var simpleproductType = this.configurableproductType;
            if (allSelected) {
                var products = this._CalcProducts();
                simpleproductType = this.options.jsonConfig.productType[products.slice().shift()];
            }
            var simplestoneType = this.configurablestoneType;
            if (allSelected) {
                var products = this._CalcProducts();
                simplestoneType = this.options.jsonConfig.stoneType[products.slice().shift()];
            }
/** */
            var simplefunktion = this.configurablefunktion;
            if (allSelected) {
                var products = this._CalcProducts();
                simplefunktion = this.options.jsonConfig.funktion[products.slice().shift()];
            }
            var durchmesser_hoehe = this.configurabledurchmesser_hoehe;
            if (allSelected) {
                var products = this._CalcProducts();
                durchmesser_hoehe = this.options.jsonConfig.durchmesser_hoehe[products.slice().shift()];
            }
            var simplethickness = this.configurablethickness;
            if (allSelected) {
                var products = this._CalcProducts();
                simplethickness = this.options.jsonConfig.thickness[products.slice().shift()];
            }
            var simpleverschlusstypen = this.configurableverschlusstypen;
            if (allSelected) {
                var products = this._CalcProducts();
                simpleverschlusstypen = this.options.jsonConfig.verschlusstypen[products.slice().shift()];
            }
            var simplelange_cm = this.configurablelange_cm;
            if (allSelected) {
                var products = this._CalcProducts();
                simplelange_cm = this.options.jsonConfig.lange_cm[products.slice().shift()];
            }
/** */


            var simplematerialLegierung = this.configurablematerialLegierung;
            if (allSelected) {
                var products = this._CalcProducts();
                simplematerialLegierung = this.options.jsonConfig.materialLegierung[products.slice().shift()];
            }
            var simplegoldlegierung = this.configurablegoldlegierung;
            if (allSelected) {
                var products = this._CalcProducts();
                simplegoldlegierung = this.options.jsonConfig.goldlegierung[products.slice().shift()];
            }
            var simplesize = this.configurablesize;
            if (allSelected) {
                var products = this._CalcProducts();
                simplesize = this.options.jsonConfig.size[products.slice().shift()];
            }
            var simplecolor = this.configurablecolor;
            if (allSelected) {
                var products = this._CalcProducts();
                simplecolor = this.options.jsonConfig.color[products.slice().shift()];
            }
            var simplequalityDetailsLabel = this.configurablequalityDetailsLabel;
            if (allSelected) {
                var products = this._CalcProducts();
                simplequalityDetailsLabel = this.options.jsonConfig.qualityDetailsLabel[products.slice().shift()];
            }
            var simplequalityDetails = this.configurablequalityDetails;
            if (allSelected) {
                var products = this._CalcProducts();
                simplequalityDetails = this.options.jsonConfig.qualityDetails[products.slice().shift()];
            }
            var simpleKlangfarbeLabel = this.configurableKlangfarbeLabel;
            if (allSelected) {
                var products = this._CalcProducts();
                simpleKlangfarbeLabel = this.options.jsonConfig.klangfarbeLabel[products.slice().shift()];
            }
            var simpleKlangfarbe = this.configurableKlangfarbe;
            if (allSelected) {
                var products = this._CalcProducts();
                simpleKlangfarbe = this.options.jsonConfig.klangfarbe[products.slice().shift()];
            }
            var simpleverpackungLabel = this.configurableverpackungLabel;
            if (allSelected) {
                var products = this._CalcProducts();
                simpleverpackungLabel = this.options.jsonConfig.verpackungLabel[products.slice().shift()];
            }
            var simpleverpackung = this.configurableverpackung;
            if (allSelected) {
                var products = this._CalcProducts();
                simpleverpackung = this.options.jsonConfig.verpackung[products.slice().shift()];
            }
            var simpleengelsruferKonzeptLabel = this.configurableengelsruferKonzeptLabel;
            if (allSelected) {
                var products = this._CalcProducts();
                simpleengelsruferKonzeptLabel = this.options.jsonConfig.engelsruferKonzeptLabel[products.slice().shift()];
            }
            var simpleengelsruferKonzeptValue = this.configurableengelsruferKonzeptValue;
            if (allSelected) {
                var products = this._CalcProducts();
                simpleengelsruferKonzeptValue = this.options.jsonConfig.engelsruferKonzeptValue[products.slice().shift()];
            }
            var simpleverpackungImage = this.configurableverpackungImage;
            if (allSelected) {
                var products = this._CalcProducts();
                simpleverpackungImage = this.options.jsonConfig.verpackungImage[products.slice().shift()];
            }
            var simpleengelsruferKonzeptImage = this.configurableengelsruferKonzeptImage;
            if (allSelected) {
                var products = this._CalcProducts();
                simpleengelsruferKonzeptImage = this.options.jsonConfig.engelsruferKonzeptImage[products.slice().shift()];
            }

            $('div.product-desc .sku-value').html(simpleSku);
            
             if (simpleDescription != null && simpleDescription !='') {
                $('div.product-desc-value').html(simpleDescription);
                $('.prod-description').removeClass('hide-attribute');
                $('.prod-description').addClass('show-attribute');
            } else {
                $('.prod-description').removeClass('show-attribute');
                $('.prod-description').addClass('hide-attribute');
            }
            if (simplebulletPoint1 != null && simplebulletPoint1 !='') {
                $('li.bullet-point1').html(simplebulletPoint1);
                $('.bullet-point1').removeClass('hide-attribute');
                $('.bullet-point1').addClass('show-attribute');
            } else {
                $('.bullet-point1').removeClass('show-attribute');
                $('.bullet-point1').addClass('hide-attribute');
            }
            if (simplebulletPoint2 != null && simplebulletPoint2 !='') {
                $('li.bullet-point2').html(simplebulletPoint2);
                $('.bullet-point2').removeClass('hide-attribute');
                $('.bullet-point2').addClass('show-attribute');
            } else {
                $('.bullet-point2').removeClass('show-attribute');
                $('.bullet-point2').addClass('hide-attribute');
            }
            if (simplebulletPoint3 != null && simplebulletPoint3 !='') {
                $('li.bullet-point3').html(simplebulletPoint3);
                $('.bullet-point3').removeClass('hide-attribute');
                $('.bullet-point3').addClass('show-attribute');
            } else {
                $('.bullet-point3').removeClass('show-attribute');
                $('.bullet-point3').addClass('hide-attribute');
            }
            if (simplebulletPoint4 != null && simplebulletPoint4 !='') {
                $('li.bullet-point4').html(simplebulletPoint4);
                $('.bullet-point4').removeClass('hide-attribute');
                $('.bullet-point4').addClass('show-attribute');
            } else {
                $('.bullet-point4').removeClass('show-attribute');
                $('.bullet-point4').addClass('hide-attribute');
            }
            if (simplebulletPoint5 != null && simplebulletPoint5 !='') {
                $('li.bullet-point5').html(simplebulletPoint5);
                $('.bullet-point5').removeClass('hide-attribute');
                $('.bullet-point5').addClass('show-attribute');
            } else {
                $('.bullet-point5').removeClass('show-attribute');
                $('.bullet-point5').addClass('hide-attribute');
            }
            if (simpleproductType != false && simpleproductType !='') {
                $('.producttype-value').html(simpleproductType);
                $('.producttype').removeClass('hide-attribute');
                $('.producttype').addClass('show-attribute');
            } else {
                $('.producttype').removeClass('show-attribute');
                $('.producttype').addClass('hide-attribute');
            }
            if (simplestoneType != null && simplestoneType !='') {
                $('.stonetype-value').html(simplestoneType);
                $('.stonetype').removeClass('hide-attribute');
                $('.stonetype').addClass('show-attribute');
            } else {
                $('.stonetype').removeClass('show-attribute');
                $('.stonetype').addClass('hide-attribute');
            }

/** added extra 5 more attribute function to show more extra attributes on the PDP by NA 30.09.19
* trello:https://trello.com/c/FUegOmvv/143-convert-csv-file-and-import-products-from-csv-file-into-relaunch-shop#comment-5d8c7cc8bf20101bda04929c
*/ 
            if (simplefunktion != null && simplefunktion !='') {
                $('.function-value').html(simplefunktion);
                $('.funktion').removeClass('hide-attribute');
                $('.funktion').addClass('show-attribute');
            } else {
                $('.funktion').removeClass('show-attribute');
                $('.funktion').addClass('hide-attribute');
            }
            if (durchmesser_hoehe != null && durchmesser_hoehe !='') {
                $('.durchmesser_hoehe-value').html(durchmesser_hoehe);
                $('.durchmesser_hoehe').removeClass('hide-attribute');
                $('.durchmesser_hoehe').addClass('show-attribute');
            } else {
                $('.durchmesser_hoehe').removeClass('show-attribute');
                $('.durchmesser_hoehe').addClass('hide-attribute');
            }
            if (simplethickness != null && simplethickness !='') {
                $('.thickness-value').html(simplethickness);
                $('.thickness').removeClass('hide-attribute');
                $('.thickness').addClass('show-attribute');
            } else {
                $('.thickness').removeClass('show-attribute');
                $('.thickness').addClass('hide-attribute');
            }
            if (simpleverschlusstypen != null && simpleverschlusstypen !='') {
                $('.verschlusstypen-value').html(simpleverschlusstypen);
                $('.verschlusstypen').removeClass('hide-attribute');
                $('.verschlusstypen').addClass('show-attribute');
            } else {
                $('.verschlusstypen').removeClass('show-attribute');
                $('.verschlusstypen').addClass('hide-attribute');
            }
            if (simplelange_cm != null && simplelange_cm !='') {
                $('.lange_cm-value').html(simplelange_cm);
                $('.lange_cm').removeClass('hide-attribute');
                $('.lange_cm').addClass('show-attribute');
            } else {
                $('.lange_cm').removeClass('show-attribute');
                $('.lange_cm').addClass('hide-attribute');
            }

            if (simplematerialLegierung != null && simplematerialLegierung !='') {
                $('.materialLegierung-value').html(simplematerialLegierung);
                $('.materialLegierung').removeClass('hide-attribute');
                $('.materialLegierung').addClass('show-attribute');
            } else {
                $('.materialLegierung').removeClass('show-attribute');
                $('.materialLegierung').addClass('hide-attribute');
            }
            if (simplegoldlegierung != false && simplegoldlegierung !='') {
                $('.goldlegierung-value').html(simplegoldlegierung);
                $('.goldlegierung').removeClass('hide-attribute');
                $('.goldlegierung').addClass('show-attribute');
            } else {
                $('.goldlegierung').removeClass('show-attribute');
                $('.goldlegierung').addClass('hide-attribute');
            }
            if (simplesize != false && simplesize !='') {
                $('.size-value').html(simplesize);
                $('.prod-size').removeClass('hide-attribute');
                $('.prod-size').addClass('show-attribute');
            } else {
                $('.prod-size').removeClass('show-attribute');
                $('.prod-size').addClass('hide-attribute');
            }
            if (simplecolor != false && simplecolor !='') {
                $('.color-value').html(simplecolor);
                $('.prod-color').removeClass('hide-attribute');
                $('.prod-color').addClass('show-attribute');
            } else {
                $('.prod-color').removeClass('show-attribute');
                $('.prod-color').addClass('hide-attribute');
            }
            if (simplequalityDetailsLabel != null && simplequalityDetailsLabel !='') {
                $('.qualityDetailsLabel').html(simplequalityDetailsLabel);
            } 
            if (simplequalityDetails != null && simplequalityDetails !='') {
                $('.qualityDetails').html(simplequalityDetails);
                $('.qualityDetails-cont').removeClass('hide-attribute');
                $('.qualityDetails-cont').addClass('show-attribute');
            } else {
                $('.qualityDetails-cont').removeClass('show-attribute');
                $('.qualityDetails-cont').addClass('hide-attribute');
            }
            if (simpleKlangfarbeLabel != null && simpleKlangfarbeLabel !='') {
                $('.klangfarbeLabel').html(simpleKlangfarbeLabel);
            } 
            if (simpleKlangfarbe != null && simpleKlangfarbe !='') {
                $('.klangfarbe').html(simpleKlangfarbe);
                $('.klangfarbe-cont').removeClass('hide-attribute');
                $('.klangfarbe-cont').addClass('show-attribute');
            } else {
                $('.klangfarbe-cont').removeClass('show-attribute');
                $('.klangfarbe-cont').addClass('hide-attribute');
            }
            if (simpleverpackungLabel != null && simpleverpackungLabel!='') {
                $('.verpackungLabel').html(simpleverpackungLabel);
            } 
            if (simpleverpackung != null && simpleverpackung !='') {
                $('.verpackung').html(simpleverpackung);
                $('.verpackung-cont').removeClass('hide-attribute');
                $('.verpackung-cont').addClass('show-attribute');
            } else {
                $('.verpackung-cont').removeClass('show-attribute');
                $('.verpackung-cont').addClass('hide-attribute');
            }
            if (simpleengelsruferKonzeptLabel != null && simpleengelsruferKonzeptLabel !='') {
                $('.engelsruferKonzeptLabel').html(simpleengelsruferKonzeptLabel);
            } 
            if (simpleengelsruferKonzeptValue != null && simpleengelsruferKonzeptValue !=""){
                $('.engelsruferKonzeptValue').html(simpleengelsruferKonzeptValue);
                $('.engelsruferKonzept-cont').removeClass('hide-attribute');
                $('.engelsruferKonzept-cont').addClass('show-attribute');
            } else {
                $('.engelsruferKonzept-cont').removeClass('show-attribute');
                $('.engelsruferKonzept-cont').addClass('hide-attribute');
            }
            if (simpleverpackungImage != null && simpleverpackungImage !='') {
                $('.verpackungImg img').attr("src", simpleverpackungImage);
            } 
            if (simpleengelsruferKonzeptImage != null && simpleengelsruferKonzeptImage !='') {
                $('.engelsruferKonzeptImage img').attr("src", simpleengelsruferKonzeptImage);
            } 
            return original();
        });

        targetModule.prototype._UpdatePrice = updatePriceWrapper;
        return targetModule;
    };
});
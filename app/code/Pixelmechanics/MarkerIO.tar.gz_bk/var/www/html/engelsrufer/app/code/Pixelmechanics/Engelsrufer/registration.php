<?php 
/*
 * Created a extension for website global requirement
 * Register extension
 * Updated by AA 24.04.2019
*/
?>
<?php
\Magento\Framework\Component\ComponentRegistrar::register(
	\Magento\Framework\Component\ComponentRegistrar::MODULE,
	'Pixelmechanics_Engelsrufer',
	__DIR__
);


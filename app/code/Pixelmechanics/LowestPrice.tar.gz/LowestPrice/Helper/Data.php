<?php
namespace Pixelmechanics\LowestPrice\Helper;

class Data extends \Magento\Framework\App\Helper\AbstractHelper
{
    protected $lowestFactory;


    protected $collectionFactory;

    public function __construct(
        \Pixelmechanics\LowestPrice\Model\LowestFactory $lowestFactory,
        \Magento\Catalog\Model\ResourceModel\Product\CollectionFactory $collectionFactory
    )
    {
        $this->lowestFactory = $lowestFactory;

        $this->collectionFactory = $collectionFactory;

    }
    public function insertInCatalogLowestPrice()
    {
      $proCollection =  $this->collectionFactory->create()->addAttributeToSelect('*')->load();
      $collection = $this->lowestFactory->create();
      $test = $proCollection->getPrice();
//      foreach($collection as $item){
//          echo $item;
//      }
        ////        print_r($productCollection);
        return $test ;
//        return $model->getCollection()->getData();
//

    }
}
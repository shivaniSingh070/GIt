<?php

namespace Pixelmechanics\LowestPrice\Cron;

class Lowest
{
    protected $lowestFactory;
    protected $_logger;
    private $state;
    protected $collectionFactory;
    protected $scopeConfig;
    protected $storeManager;
    protected $rule;

    public function __construct(
        \Pixelmechanics\LowestPrice\Model\LowestFactory $lowestFactory,
        \Magento\Catalog\Model\ResourceModel\Product\CollectionFactory $collectionFactory ,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\CatalogRule\Model\Rule $rule,
        \Magento\Framework\App\State $state,
      
        \Psr\Log\LoggerInterface $logger
    )
    {
        $this->lowestFactory = $lowestFactory;
        $this->state = $state;
        $this->scopeConfig = $scopeConfig;
        $this->storeManager = $storeManager;
        $this->collectionFactory = $collectionFactory;
        $this->_logger = $logger;
        $this->rule = $rule ; 
    

    }
    public function execute()
    {
        
        $isModuleEnable = $this->scopeConfig->getValue("lowest_price/general/enable",
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE, $this->storeManager->getStore()->getStoreId());
        if($isModuleEnable) {

            $productCollection = $this->collectionFactory->create()->addAttributeToSelect('*')->load();
            $model = $this->lowestFactory->create();
            $modelCollection = $model->getCollection();

            foreach ($productCollection as $product) {
                $regularPrice = $product->getPrice();
                $finalPrice = $product->getFinalPrice();
                $catalogPrice = $this->rule->calcProductPriceRule($product, $regularPrice);
                $entityId = $product->getEntityId();
                $currentDate = date("Y-m-d");
                $savedProductDetail = $modelCollection
                    ->addFieldToFilter('product_id', array('eq' => $entityId))
                    ->addFieldToFilter('date', array('eq' => $currentDate))->getFirstItem()->debug();
              
                $currentLowestPrice = ($finalPrice < $regularPrice) ? $finalPrice :$regularPrice;
                $currentLowestPrice = ($currentLowestPrice < $catalogPrice) ? $currentLowestPrice: $catalogPrice;
                
                if (!$savedProductDetail) {
                   
                    $data = [
                        'product_id' => $entityId,
                        'date' => $currentDate,
                        'lowest_total_price' => $currentLowestPrice
                    ];
                    $model->setData($data)->save();
                } else {

                    if ($savedProductDetail['id']) {
                        
                        $model = $this->lowestFactory->create();
                        $model->load($savedProductDetail['id']);
                        $model->setDate($currentDate);
                        $model->setLowestTotalPrice($currentLowestPrice);
                        $model->save();
                          
                    }
                }

            }
            $this->_logger->info("dgfcgf");

            return $this;

        }
    }

}
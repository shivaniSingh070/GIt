<?php
namespace Pixelmechanics\LowestPrice\Logger;

class Logger extends \Monolog\Logger
{
}